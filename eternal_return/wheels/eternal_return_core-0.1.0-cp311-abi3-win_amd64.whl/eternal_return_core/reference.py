"""Pure-Python reference implementation of the Eternal Return drone flight core.

Two modules in one file, both written from the specs in ``spec/``:

- the drone physics (``spec/physics.md``): ``step`` advances a drone state by one tick in the simulation frame;
- the stick rates (``spec/rates.md``): ``sticks_to_commands`` turns raw stick positions into physics commands.

This is the readable model the compiled core is checked against, so it favours plain math over speed. It uses
only the standard library and float64 throughout.
"""

import math
from dataclasses import dataclass, field


# ---------------------------------------------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------------------------------------------

def _floats(values, n):
    """Return ``values`` as a tuple of ``n`` floats, so every state holds plain float64 tuples."""
    t = tuple(float(c) for c in values)
    if len(t) != n:
        raise ValueError(f"expected {n} components, got {len(t)}")
    return t


@dataclass(frozen=True)
class DroneState:
    """The drone's position (m), velocity (m/s) and orientation quaternion (w, x, y, z) in the simulation frame."""

    position: tuple = (0.0, 0.0, 0.0)
    velocity: tuple = (0.0, 0.0, 0.0)
    orientation: tuple = (1.0, 0.0, 0.0, 0.0)

    def __post_init__(self):
        # Frozen, so the coercion has to go through object.__setattr__; it lets callers pass lists or ints.
        object.__setattr__(self, "position", _floats(self.position, 3))
        object.__setattr__(self, "velocity", _floats(self.velocity, 3))
        object.__setattr__(self, "orientation", _floats(self.orientation, 4))

    def __repr__(self):
        def fmt(t):
            return "(" + ", ".join(f"{c:.6g}" for c in t) + ")"
        return (f"DroneState(position={fmt(self.position)}, velocity={fmt(self.velocity)}, "
                f"orientation={fmt(self.orientation)})")


@dataclass(frozen=True)
class Commands:
    """One tick's physics input: thrust in newtons along local +Z and rotation rates in rad/s about local X, Y, Z."""

    thrust: float = 0.0
    pitch_rate: float = 0.0
    roll_rate: float = 0.0
    yaw_rate: float = 0.0


@dataclass(frozen=True)
class DroneParams:
    """Physical constants of the drone and its world; ``ground_z`` and ``angle_limit`` are off when None."""

    mass: float = 0.5
    gravity: tuple = (0.0, 0.0, -9.81)
    drag_coefficient: float = 0.8
    air_density: float = 1.225
    reference_area: float = 0.04
    ground_z: float = None
    auto_level_strength: float = 0.0
    angle_limit: float = None

    def __post_init__(self):
        object.__setattr__(self, "gravity", _floats(self.gravity, 3))


# ---------------------------------------------------------------------------------------------------------------
# Quaternions and Euler angles
# ---------------------------------------------------------------------------------------------------------------

def _quat_mul(a, b):
    """Hamilton product a ⊗ b of two (w, x, y, z) quaternions."""
    aw, ax, ay, az = a
    bw, bx, by, bz = b
    return (aw * bw - ax * bx - ay * by - az * bz,
            aw * bx + ax * bw + ay * bz - az * by,
            aw * by - ax * bz + ay * bw + az * bx,
            aw * bz + ax * by - ay * bx + az * bw)


def _normalized(q):
    n = math.sqrt(sum(c * c for c in q))
    return tuple(c / n for c in q)


def _matrix(q):
    """Rotation matrix (rows of column-vector form) of q, mapping local axes into the frame.

    Scaling by 2 / |q|² instead of 2 keeps the matrix a pure rotation even if q drifted slightly off unit length.
    """
    w, x, y, z = q
    s = 2.0 / (w * w + x * x + y * y + z * z)
    return ((1 - s * (y * y + z * z), s * (x * y - w * z), s * (x * z + w * y)),
            (s * (x * y + w * z), 1 - s * (x * x + z * z), s * (y * z - w * x)),
            (s * (x * z - w * y), s * (y * z + w * x), 1 - s * (x * x + y * y)))


def _euler_from_matrix(m):
    """XYZ Euler angles of R = Rz(ez)·Ry(ey)·Rx(ex), picking between the two solutions exactly as the spec says.

    The smaller-sum choice matters: auto-level and the angle limit act on these angles, so the other valid
    answer would fly differently.
    """
    cy = math.hypot(m[0][0], m[1][0])
    if cy > 16 * 2.0 ** -23:
        e1 = (math.atan2(m[2][1], m[2][2]), math.atan2(-m[2][0], cy), math.atan2(m[1][0], m[0][0]))
        e2 = (math.atan2(-m[2][1], -m[2][2]), math.atan2(-m[2][0], -cy), math.atan2(-m[1][0], -m[0][0]))
        return e2 if sum(abs(c) for c in e1) > sum(abs(c) for c in e2) else e1
    # Gimbal lock: x and z turn about the same axis, so all of it is put on x.
    return (math.atan2(-m[1][2], m[1][1]), math.atan2(-m[2][0], cy), 0.0)


def euler_xyz(q):
    """XYZ Euler angles (ex, ey, ez) of the orientation quaternion q, as defined in spec/physics.md."""
    return _euler_from_matrix(_matrix(q))


def quat_from_euler_xyz(e):
    """Quaternion qz(ez) ⊗ qy(ey) ⊗ qx(ex) of XYZ Euler angles e, the inverse of ``euler_xyz``."""
    ex, ey, ez = e
    qx = (math.cos(ex / 2), math.sin(ex / 2), 0.0, 0.0)
    qy = (math.cos(ey / 2), 0.0, math.sin(ey / 2), 0.0)
    qz = (math.cos(ez / 2), 0.0, 0.0, math.sin(ez / 2))
    return _quat_mul(qz, _quat_mul(qy, qx))


# ---------------------------------------------------------------------------------------------------------------
# Physics
# ---------------------------------------------------------------------------------------------------------------

def step(state, commands, params, dt):
    """Advance ``state`` by ``dt`` seconds under ``commands`` and ``params``; returns a new DroneState.

    Follows the seven ordered sub-steps of spec/physics.md: gravity, this step's rotation, thrust, implicit
    quadratic drag, move, ground, turn.
    """
    p = list(state.position)
    v = list(state.velocity)
    q = state.orientation
    m = _matrix(q)  # the orientation at the start of the step, used for the Euler reading and for thrust

    # 1. Gravity.
    for i in range(3):
        v[i] += params.gravity[i] * dt

    # 2. Rotation for this step, as XYZ Euler angles in local space.
    r = [commands.pitch_rate, commands.roll_rate, commands.yaw_rate]
    leveling = params.auto_level_strength > 0
    limiting = params.angle_limit is not None
    e = _euler_from_matrix(m) if (leveling or limiting) else None
    if leveling:
        # Yaw is never leveled: there's no "level" heading.
        r[0] -= 10 * params.auto_level_strength * e[0]
        r[1] -= 10 * params.auto_level_strength * e[1]
    d = [r[0] * dt, r[1] * dt, r[2] * dt]
    if limiting:
        # Adds Euler angles as if independent; an approximation, but it's how the add-on has always flown.
        limit = params.angle_limit
        for i in (0, 1):
            n = e[i] + d[i]
            if abs(n) > limit:
                d[i] -= math.copysign(abs(n) - limit, n)

    # 3. Thrust along local +Z, i.e. the third column of R.
    push = commands.thrust / params.mass * dt
    for i in range(3):
        v[i] += m[i][2] * push

    # 4. Drag. Implicit in u, so even a huge dt only shrinks the speed toward zero and never reverses v.
    u = math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2])
    if u > 0:
        a = 0.5 * params.drag_coefficient * params.air_density * params.reference_area * u * u / params.mass
        f = u / (u + a * dt)
        v = [c * f for c in v]

    # 5. Move with the velocity after drag (semi-implicit Euler).
    for i in range(3):
        p[i] += v[i] * dt

    # 6. Ground: a floor plane that stops downward motion but lets the drone slide.
    if params.ground_z is not None and p[2] < params.ground_z:
        p[2] = params.ground_z
        v[2] = max(v[2], 0.0)

    # 7. Turn. Post-multiplying applies the turn in the drone's local axes.
    q = _normalized(_quat_mul(q, quat_from_euler_xyz(d)))

    return DroneState(p, v, q)


# ---------------------------------------------------------------------------------------------------------------
# Rates: sticks to commands
# ---------------------------------------------------------------------------------------------------------------

AXES = ("throttle", "yaw", "pitch", "roll")
ROTATION_AXES = ("yaw", "pitch", "roll")
MODES = ("ACRO", "3D", "HORIZON", "ANGLE")


@dataclass(frozen=True)
class Sticks:
    """Raw normalized stick positions in [-1, 1], already mapped to axes by the host."""

    throttle: float = 0.0
    yaw: float = 0.0
    pitch: float = 0.0
    roll: float = 0.0


def _per_axis(axes, value):
    return field(default_factory=lambda: {axis: value(axis) for axis in axes})


@dataclass(frozen=True)
class StickSettings:
    """How sticks become commands. Per-axis fields are dicts keyed by axis name; rates are in rad/s.

    A per-axis dict may name only some axes: the rest keep their spec defaults.
    """

    mode: str = "ACRO"
    invert: dict = _per_axis(AXES, lambda axis: axis in ("throttle", "yaw"))
    deadzone: dict = _per_axis(AXES, lambda axis: 0.1)
    throttle_centered: bool = True
    max_thrust: float = 30.0
    center_rate: dict = _per_axis(ROTATION_AXES, lambda axis: math.radians(145))
    max_rate: dict = _per_axis(ROTATION_AXES, lambda axis: math.radians(533))
    expo: dict = _per_axis(ROTATION_AXES, lambda axis: 0.5)
    auto_level_strength: float = 0.2
    angle_limit: float = math.radians(60)

    def __post_init__(self):
        if self.mode not in MODES:
            raise ValueError(f"mode must be one of {MODES}, got {self.mode!r}")
        defaults = StickSettings.__dataclass_fields__
        for name in ("invert", "deadzone", "center_rate", "max_rate", "expo"):
            merged = defaults[name].default_factory()
            merged.update(getattr(self, name))
            object.__setattr__(self, name, merged)
        # A deadzone covering the whole stick would divide by zero; the spec (and the compiled core) reject it.
        for axis, z in self.deadzone.items():
            if not 0.0 <= z < 1.0:
                raise ValueError(f"deadzone for {axis} must be in [0, 1), got {z!r}")


def actual_rate(x, center_rate, max_rate, expo):
    """Rotation rate (rad/s) for stick x in [-1, 1]: slope ``center_rate`` at the center, ±``max_rate`` at the ends.

    Close to Betaflight's "Actual" rates but uses |x|^expo where Betaflight uses |x|; kept exactly as the add-on
    flies. Python's 0.0 ** 0 is 1, which is the spec's convention for expo 0.
    """
    shaped = abs(x) ** expo * (expo * x ** 5 + (1 - expo) * x)
    return center_rate * x + (max_rate - center_rate) * shaped


def _shaped_stick(axis, x, settings):
    """Apply invert, the throttle range and the deadzone to one raw stick position."""
    if settings.invert[axis]:
        x = -x
    if axis == "throttle" and settings.mode != "3D":
        if not settings.throttle_centered:
            x = (x + 1) / 2
        # Outside 3D mode the throttle never pushes down.
        x = min(max(x, 0.0), 1.0)
    z = settings.deadzone[axis]
    if z > 0:
        # copysign keeps x = 0 at 0 (the clamp is 0 there), never NaN.
        x = math.copysign(min(max((abs(x) - z) / (1 - z), 0.0), 1.0), x)
    return x


def sticks_to_commands(sticks, settings):
    """Turn raw ``sticks`` into physics Commands: thrust in newtons and pitch, roll and yaw rates in rad/s."""
    x = {axis: _shaped_stick(axis, float(getattr(sticks, axis)), settings) for axis in AXES}
    t = x["throttle"]
    rates = {axis: actual_rate(x[axis], settings.center_rate[axis], settings.max_rate[axis], settings.expo[axis])
             for axis in ROTATION_AXES}
    return Commands(thrust=math.copysign(settings.max_thrust * t * t, t),
                    pitch_rate=rates["pitch"], roll_rate=rates["roll"], yaw_rate=rates["yaw"])


def flight_mode_params(settings):
    """The physics' (auto_level_strength, angle_limit) for the settings' flight mode; angle_limit None means off."""
    if settings.mode in ("HORIZON", "ANGLE"):
        return (settings.auto_level_strength, settings.angle_limit if settings.mode == "ANGLE" else None)
    return (0.0, None)
