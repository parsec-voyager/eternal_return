"""Eternal Return drone flight core: drone physics and stick rates.

The public names come from the compiled ``_native`` module when it's built, and from the pure-Python
``reference`` module otherwise. Both expose the same API, so callers never need to know which one they got;
``IMPLEMENTATION`` says which ("native" or "reference") for logs and tests.
"""

__all__ = [
    "DroneState", "Commands", "DroneParams", "step", "euler_xyz", "quat_from_euler_xyz",
    "Sticks", "StickSettings", "sticks_to_commands", "actual_rate", "flight_mode_params",
    "IMPLEMENTATION",
]

try:
    from . import _native as _impl
    IMPLEMENTATION = "native"
except ImportError:
    from . import reference as _impl
    IMPLEMENTATION = "reference"

DroneState = _impl.DroneState
Commands = _impl.Commands
DroneParams = _impl.DroneParams
step = _impl.step
euler_xyz = _impl.euler_xyz
quat_from_euler_xyz = _impl.quat_from_euler_xyz
Sticks = _impl.Sticks
StickSettings = _impl.StickSettings
sticks_to_commands = _impl.sticks_to_commands
actual_rate = _impl.actual_rate
flight_mode_params = _impl.flight_mode_params
